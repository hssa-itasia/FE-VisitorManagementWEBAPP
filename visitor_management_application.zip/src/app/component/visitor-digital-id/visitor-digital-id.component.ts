import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-visitor-digital-id',
  templateUrl: './visitor-digital-id.component.html',
  styleUrl: './visitor-digital-id.component.scss'
})
export class VisitorDigitalIdComponent {
  constructor(private router:Router){

  }
  onClose(){
this.router.navigateByUrl('/confirmation');
  }
}
