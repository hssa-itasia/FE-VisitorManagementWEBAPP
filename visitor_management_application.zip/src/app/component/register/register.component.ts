import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent {
constructor(private router:Router){

}
onSubmit(){
this.router.navigateByUrl('/id-card')
}
takePicture(){
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then((stream) => {
        const video = document.createElement('video');
        video.srcObject = stream;
        video.onloadedmetadata = () => {
          video.play();
        };

        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext('2d');
        
        if (context) { // Check if context is not null
          setTimeout(() => {
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = canvas.toDataURL('image/png');
            sessionStorage.setItem('capturedImage', imageData); // Store image data in session storage
            video.srcObject = null;
            this.router.navigate(['/display-image']); // Navigate to the page to display the image
          }, 500); // Adjust timeout as needed for camera initialization
        } else {
          console.error('Canvas context is null');
        }
      })
      .catch((error) => {
        console.error('Error accessing the camera: ', error);
      });
  } else {
    console.error('getUserMedia is not supported');
  }
}
}
